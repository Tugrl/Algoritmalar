﻿#include<stdio.h>

#include<stdlib.h>
#define MAX_TERM 101
#define _K 4
#define _L 4
#define _M 4
void multiply();
void print();


typedef struct {
	int row;
	int column;
	int value;
}non_zero_values;


int main() {
	int sparse_matrix_1[_K][_L] = { {0 , 10 , 0 , 5 }, {0 , 2 , 4 , 0 }, {0 , 0 , 0 , 0 }, {3 , 0 , 0 , 7 } };

	int count = 1;
	
	
	non_zero_values compact_matrix_1[MAX_TERM]; //referenced by ceng205_assignment1.pdf
	compact_matrix_1[0].row = 4;
	compact_matrix_1[0].column = 4;
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			if (sparse_matrix_1[i][j] != 0) {
				compact_matrix_1[count].row = i;
				compact_matrix_1[count].column = j;
				compact_matrix_1[count].value = sparse_matrix_1[i][j];
				count++;
			}
		}
	}
	compact_matrix_1[0].value = count;
	
	printf("First Matrix:\n"); //print first matrix
	for (int i = 1; i < count ; i++)
	{

		printf("%d\t %d\t %d \n", compact_matrix_1[i].row+1, compact_matrix_1[i].column+1, compact_matrix_1[i].value);
	}

	multiply(compact_matrix_1);
	
	

}
void multiply(non_zero_values compact_matrix[MAX_TERM]) {//multiply function
	int sparse_matrix_2[_L][_M] = { {1 , 0 , 0 , 2 }, {0 , 0 , 3 , 0 }, {0 , 8 , 0 , 0 }, {5 , 0 , 10 , 0 } };//referenced by ceng205_assignment1.pdf
	non_zero_values compact_matrix_2[MAX_TERM];
	non_zero_values result_matrix[MAX_TERM];

	int count2 = 1;
	int count3 = 1;
	compact_matrix_2[0].row = 4;
	compact_matrix_2[0].column = 4;
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			if (sparse_matrix_2[i][j] != 0) {
				compact_matrix_2[count2].row = i;
				compact_matrix_2[count2].column = j;
				compact_matrix_2[count2].value = sparse_matrix_2[i][j];
				count2++;
			}
		}
	}
	compact_matrix_2[0].value = count2;


	non_zero_values compact_matrix_3[MAX_TERM];  //referenced by ceng205-ders4.pdf
	int n, currentb;
	n = compact_matrix_2[0].value;
	compact_matrix_3[0].row = compact_matrix_2[0].column;
	compact_matrix_3[0].column = compact_matrix_2[0].row;
	compact_matrix_3[0].value = n;

	if (n > 0) {
		currentb = 1;
		for (int i = 0; i < compact_matrix_2[0].column; i++) {
			for (int j = 1; j <= n; j++) {
				if (compact_matrix_2[j].column == i) {
					compact_matrix_3[currentb].row = compact_matrix_2[j].column;
					compact_matrix_3[currentb].column = compact_matrix_2[j].row;
					compact_matrix_3[currentb].value = compact_matrix_2[j].value;
					currentb++;

				}
			}
		}
	}


	printf("Second Matrix:\n");//print transposed matrix
	for (int i = 1; i < compact_matrix_3[0].value; i++)
	{

		printf("%d\t %d\t %d \n", compact_matrix_3[i].row + 1, compact_matrix_3[i].column + 1, compact_matrix_3[i].value);
	}


	result_matrix[0].row = 4;
	result_matrix[0].column = 4;

	int count4 = 0;


	for (int i = 1; i < count2; i++) {//start of multiply
		for (int j = 1; j < count2; j++) {
			if (compact_matrix[i].column == compact_matrix_3[j].column) {

				result_matrix[count3].row = compact_matrix[i].row;
				result_matrix[count3].column = compact_matrix_3[j].row;
				result_matrix[count3].value = compact_matrix[i].value * compact_matrix_3[j].value;
				count3++;
			}


		}
	}
	result_matrix[0].value = count3;

	for (int i = 1; i < count3; i++) {
		for (int j = 1; j < count3; j++) {
			if (i != j && i > j) {
				if (result_matrix[i].row == result_matrix[j].row && result_matrix[i].column == result_matrix[j].column) {

					result_matrix[i].value = result_matrix[i].value + result_matrix[j].value;
				}
			}

		}
	}//end of multiply

	int temporary = 0;
	int temporary2 = 0;
	int temporary3 = 0;//temp items for bubble sort


	for (int i = 1; i < result_matrix[0].value; i++) {  //referenced by this website link: https://gurelahmet.com/c-dilinde-siralama-algoritmalari/
		for (int j = 1; j < result_matrix[0].value - 1; j++) {
			if (result_matrix[j].column > result_matrix[j + 1].column) {

				temporary = result_matrix[j + 1].column;
				result_matrix[j + 1].column = result_matrix[j].column;
				result_matrix[j].column = temporary;

				temporary2 = result_matrix[j + 1].row;
				result_matrix[j + 1].row = result_matrix[j].row;
				result_matrix[j].row = temporary2;

				temporary3 = result_matrix[j + 1].value;
				result_matrix[j + 1].value = result_matrix[j].value;
				result_matrix[j].value = temporary3;
			}
		}
	}
	
		print(result_matrix);
	
}
void print(non_zero_values result_matrix[MAX_TERM]) { //print matrix function


	printf("Sparse Matrix Multiplication:\nRow\tColumn\tValue\n");
	printf("%d\t %d\t %d \n", result_matrix[0].row, result_matrix[0].column, result_matrix[0].value-1);
	for (int i = 1; i <result_matrix[0].value ; i++)
	{

		printf("%d\t %d\t %d \n", result_matrix[i].row+1, result_matrix[i].column+1, result_matrix[i].value);

	}
}

